update cadmov set cenviadotc = 'N' where nmespgto is null and nanopgto is null;
update cadmov set cenviadrvg = 'N' where nmespgto is null and nanopgto is null;